
## Dependencies

```console
pip install requests youtube_dl
```

## Run Code

```console
$ python main.py
```