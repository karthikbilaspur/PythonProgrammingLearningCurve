# Code For Python Speech Recognition Course

Watch the video:

 [![Alt text](https://img.youtube.com/vi/mYUyaKmvu6Y/hqdefault.jpg)](https://youtu.be/mYUyaKmvu6Y)
