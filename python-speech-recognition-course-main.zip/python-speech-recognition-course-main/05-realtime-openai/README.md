
## Dependencies

```console
$ pip install pyaudio requests websockets openai
```

## Run Code

```console
$ python main.py
```